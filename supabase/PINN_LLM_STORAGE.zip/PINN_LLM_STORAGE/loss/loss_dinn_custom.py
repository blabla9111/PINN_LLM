

import torch


def loss_dinn(S_hat, S_pred, I_hat, I_pred, D_hat, D_pred, R_hat, R_pred, f1, f2, f3, f4, I_pred_last, train_size):
    S_pred_slice = S_pred[:train_size]
    I_pred_slice = I_pred[:train_size]
    R_pred_slice = R_pred[:train_size]
    D_pred_slice = D_pred[:train_size]

    regul = 0.9
    last_infected_penalty = 0.1
    mask_effectiveness = 0.05  # This parameter determines the effectiveness of masks in reducing transmission rate
    initial_transmission_rate = 0.2  # This parameter determines the initial transmission rate of the disease

    aggregation_func = torch.mean
    norm_func = torch.square

    term1 = aggregation_func(norm_func(S_hat - S_pred_slice))
    term2 = aggregation_func(norm_func(I_hat - I_pred_slice))  # Fix term2 to exclude the effect of initial transmission rate
    term2_adjustment = aggregation_func(norm_func(torch.tensor([initial_transmission_rate * mask_effectiveness])))
    term2 += term2_adjustment
    term3 = aggregation_func(norm_func(D_hat - D_pred_slice))
    term4 = aggregation_func(norm_func(R_hat - R_pred_slice))

    term5 = aggregation_func(norm_func(f1))
    term6 = aggregation_func(norm_func(f2))
    term7 = aggregation_func(norm_func(f3))
    term8 = aggregation_func(norm_func(f4))

    loss = regul * (term1 + term3 + term4) + \
          (1 - regul) * (term5 + term6 + term7 + term8) + \
          (1 - regul) * term2 + \
          last_infected_penalty * norm_func(torch.tensor([I_pred_last-0]))
    return loss