import torch


def loss_dinn(S_hat, S_pred, I_hat, I_pred, D_hat, D_pred, R_hat, R_pred, f1, f2, f3, f4, I_pred_last, train_size):
    S_pred_slice = S_pred[:train_size]
    I_pred_slice = I_pred[:train_size]
    R_pred_slice = R_pred[:train_size]
    D_pred_slice = D_pred[:train_size]

    regul = 0.9
    last_infected_penalty = 0.1

    aggregation_func = torch.mean
    norm_func = torch.square

    peak_index = torch.argmax(I_pred_slice)
    term1 = aggregation_func(norm_func(S_hat - S_pred_slice))
    epidemic_peak_penalty = torch.mean(torch.where(I_pred_slice >= I_pred_slice[peak_index] - torch.std(I_pred_slice[peak_index - 3:peak_index + 3]) * 2,
                                                  norm_func(I_pred_slice - I_pred_slice[peak_index]), torch.tensor(0., dtype=torch.float64)))

    term2 = aggregation_func(norm_func(I_hat - I_pred_slice))
    term3 = aggregation_func(norm_func(D_hat - D_pred_slice))
    term4 = aggregation_func(norm_func(R_hat - R_pred_slice))

    term5 = aggregation_func(norm_func(f1))
    term6 = aggregation_func(norm_func(f2))
    term7 = aggregation_func(norm_func(f3))
    term8 = aggregation_func(norm_func(f4))

    loss = regul * (term1 + 0.2 * term2 + term3 + term4) + \
            (1 - regul) * (term5 + term6 + term7 + term8) + \
            last_infected_penalty * torch.mean(norm_func(I_pred_last - 0)) + \
            0.6 * aggregation_func(norm_func(epidemic_peak_penalty))

    return loss